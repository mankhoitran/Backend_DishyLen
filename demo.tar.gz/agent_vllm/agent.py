"""vLLM-driven agent loop using DuckDuckGo search."""

from __future__ import annotations

import logging
from typing import Any

from sqlalchemy.orm import Session

from agent.parser import parse_input
from config import get_settings
from food_agent_vllm.search import DuckDuckGoSearchService
from food_agent_vllm.tools import VLLMAgentTools
from food_agent_vllm.vllm_client import VLLMClient

logger = logging.getLogger(__name__)


class VLLMFoodAgent:
    """Tool-driven food information agent powered by vLLM and DuckDuckGo."""

    def __init__(self, db: Session) -> None:
        self.settings = get_settings()
        self.vllm_client = VLLMClient()
        self.search_service = DuckDuckGoSearchService(
            self.vllm_client,
            max_results=self.settings.duckduckgo_max_results,
        )
        self.tools = VLLMAgentTools(db=db, search_service=self.search_service)

    def run(self, query: str, target_language: str | None = None) -> dict[str, Any]:
        """Execute end-to-end dish information workflow."""

        parsed = parse_input(query)
        logger.info("Parsed input type=%s dish=%s", parsed.input_type, parsed.dish_name)

        collected: dict[str, Any] = {
            "dish": parsed.dish_name,
            "spicy_level": "unknown",
            "macros": {},
            "summary": "",
            "image_url": "",
            "source": "search",
        }

        existing = self.tools.get_processed_dish(parsed.dish_name)
        collected = self._merge_collected(collected, existing)

        if existing.get("found") is not True:
            search_payload = self.tools.search_dish(parsed.dish_name)
            collected = self._merge_collected(collected, search_payload)

            if collected.get("spicy_level") in (None, "", "unknown"):
                collected = self._merge_collected(
                    collected,
                    self.tools.get_spicy_level(parsed.dish_name),
                )

            if self._macros_missing(collected.get("macros")):
                collected = self._merge_collected(
                    collected,
                    self.tools.get_dish_macro(parsed.dish_name),
                )

            if not collected.get("summary"):
                collected = self._merge_collected(
                    collected,
                    self.tools.get_dish_summary(parsed.dish_name),
                )

            if not collected.get("image_url"):
                collected = self._merge_collected(
                    collected,
                    self.tools.get_dish_image_url(parsed.dish_name),
                )

        if target_language and collected.get("summary"):
            translated = self.tools.translate(collected["summary"], target_language)
            collected["summary"] = translated.get("translated_text", collected["summary"])

        if collected.get("source") == "search":
            self.tools.persist_dish(
                dish_name=collected.get("dish", parsed.dish_name),
                spicy_level=collected.get("spicy_level", "unknown"),
                macros=collected.get("macros", {}),
                summary=collected.get("summary", ""),
            )

        return {
            "dish": collected.get("dish", parsed.dish_name),
            "spicy_level": collected.get("spicy_level", "unknown"),
            "macros": collected.get("macros", {}),
            "summary": collected.get("summary", ""),
            "image_url": collected.get("image_url", ""),
            "source": collected.get("source", "search"),
        }

    @staticmethod
    def _merge_collected(current: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
        """Merge non-empty tool outputs into collected state."""

        merged = dict(current)
        for key in ("dish", "spicy_level", "summary", "image_url", "source"):
            value = incoming.get(key)
            if value:
                merged[key] = value

        incoming_macros = incoming.get("macros")
        if isinstance(incoming_macros, dict) and incoming_macros:
            merged["macros"] = incoming_macros

        if incoming.get("found") is True:
            merged["source"] = "database"

        return merged

    @staticmethod
    def _macros_missing(macros: dict[str, Any] | None) -> bool:
        if not isinstance(macros, dict) or not macros:
            return True

        required = ["calories_kcal", "protein_g", "carbs_g", "fat_g"]
        values = [macros.get(key) for key in required]
        return all(value in (None, "", "unknown") for value in values)
