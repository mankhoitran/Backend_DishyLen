"""Menu image demo using the vLLM-backed agent."""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path
from typing import Any

from agent_vllm.agent import VLLMFoodAgent
from agent_vllm.vllm_client import VLLMClient
from db.database import Base, SessionLocal, engine

DEFAULT_IMAGE_PATH = Path(__file__).resolve().parents[1] / "menu_test_image" / "menu.png"

FALLBACK_MENU_TEXT = """Menu and Prices:
Grilled Chicken Caesar Salad
Classic Club Sandwich
Spinach and Feta Stuffed Chicken
Vegetable Quinoa Bowl
BBQ Pulled Pork Sandwich
Caprese Panini
Fish Tacos
Mushroom and Swiss Burger
Quiche Lorraine
Mediterranean Pasta
Asian Chicken Salad
Beef Stir-Fry
Margherita Pizza
Roasted Vegetable Wrap
Soup of the Day
Beverages:
Soft Drinks
Iced Tea
Freshly Squeezed Lemonade
Fruit Smoothies
Coffee
Hot Tea
Bottled Water
"""

FALLBACK_ITEMS: list[dict[str, str]] = [
    {"name": "Grilled Chicken Caesar Salad", "category": "food"},
    {"name": "Classic Club Sandwich", "category": "food"},
    {"name": "Spinach and Feta Stuffed Chicken", "category": "food"},
    {"name": "Vegetable Quinoa Bowl", "category": "food"},
    {"name": "BBQ Pulled Pork Sandwich", "category": "food"},
    {"name": "Caprese Panini", "category": "food"},
    {"name": "Fish Tacos", "category": "food"},
    {"name": "Mushroom and Swiss Burger", "category": "food"},
    {"name": "Quiche Lorraine", "category": "food"},
    {"name": "Mediterranean Pasta", "category": "food"},
    {"name": "Asian Chicken Salad", "category": "food"},
    {"name": "Beef Stir-Fry", "category": "food"},
    {"name": "Margherita Pizza", "category": "food"},
    {"name": "Roasted Vegetable Wrap", "category": "food"},
    {"name": "Soup of the Day", "category": "food"},
    {"name": "Soft Drinks", "category": "beverage"},
    {"name": "Iced Tea", "category": "beverage"},
    {"name": "Freshly Squeezed Lemonade", "category": "beverage"},
    {"name": "Fruit Smoothies", "category": "beverage"},
    {"name": "Coffee", "category": "beverage"},
    {"name": "Hot Tea", "category": "beverage"},
    {"name": "Bottled Water", "category": "beverage"},
]


def _try_ocr(image_path: Path) -> tuple[str, str]:
    if not image_path.exists():
        raise FileNotFoundError(f"Image not found: {image_path}")

    try:
        from PIL import Image
        import pytesseract
    except Exception as exc:  # pragma: no cover - optional deps
        logging.warning("OCR dependencies missing, using fallback text: %s", exc)
        return "", "missing_deps"

    try:
        text = pytesseract.image_to_string(Image.open(image_path))
        return (text or "").strip(), "ocr"
    except Exception as exc:  # pragma: no cover - optional deps
        logging.warning("OCR failed, using fallback text: %s", exc)
        return "", "ocr_failed"


def _extract_items_with_llm(vllm_client: VLLMClient, ocr_text: str) -> list[dict[str, str]]:
    source_text = ocr_text.strip() or FALLBACK_MENU_TEXT

    system_prompt = (
        "You extract menu items from OCR text. Return strict JSON only."
    )
    user_prompt = (
        "Return JSON with key items as an array of objects. "
        "Each item must include name and category. "
        "category must be food or beverage. "
        "If unsure, use food. "
        f"OCR text:\n{source_text}"
    )

    payload = vllm_client.generate_json(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        fallback={"items": []},
    )

    items = payload.get("items")
    if not isinstance(items, list):
        return FALLBACK_ITEMS

    seen: set[str] = set()
    cleaned: list[dict[str, str]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).strip()
        if not name:
            continue
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        category = str(item.get("category", "food")).strip().lower() or "food"
        if category not in ("food", "beverage"):
            category = "food"
        cleaned.append({"name": name, "category": category})

    return cleaned or FALLBACK_ITEMS


def _build_information_form(
    agent: VLLMFoodAgent,
    items: list[dict[str, str]],
    limit: int,
    target_language: str | None,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for item in items[:limit]:
        info = agent.run(query=item["name"], target_language=target_language)
        results.append(
            {
                "name": item["name"],
                "category": item.get("category", "food"),
                "dish_info": info,
            }
        )
    return results


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Menu image demo using agent_vllm.")
    parser.add_argument("--image", type=Path, default=DEFAULT_IMAGE_PATH)
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--target-language", type=str, default=None)
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--skip-ocr", action="store_true")
    return parser.parse_args()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
    args = _parse_args()

    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        vllm_client = VLLMClient()
        agent = VLLMFoodAgent(db=db)

        ocr_text = ""
        ocr_status = "skipped"
        if not args.skip_ocr:
            ocr_text, ocr_status = _try_ocr(args.image)

        items = _extract_items_with_llm(vllm_client, ocr_text)
        if args.limit <= 0:
            limit = len(items)
        else:
            limit = min(args.limit, len(items))

        results = _build_information_form(agent, items, limit, args.target_language)
        payload = {
            "menu_image": str(args.image),
            "ocr_status": ocr_status,
            "items_extracted": len(items),
            "items": results,
        }

        output_text = json.dumps(payload, indent=2, ensure_ascii=True)
        if args.output:
            args.output.write_text(output_text, encoding="utf-8")
            logging.info("Wrote output to %s", args.output)
        else:
            print(output_text)
    finally:
        db.close()


if __name__ == "__main__":
    main()
