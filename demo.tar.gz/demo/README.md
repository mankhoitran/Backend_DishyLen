# vLLM Menu Demo (Qwen2.5-7B-Instruct)

This demo uses the vLLM-backed agent to turn a menu image into structured dish information.

## 1) Start vLLM (OpenAI-compatible)

### Option A: Python

```bash
python -m vllm.entrypoints.openai.api_server \
  --model Qwen/Qwen2.5-7B-Instruct \
  --served-model-name Qwen2.5-7B-Instruct \
  --port 8001
```

### Option B: Docker

```bash
docker run --gpus all -p 8001:8000 vllm/vllm-openai:latest \
  --model Qwen/Qwen2.5-7B-Instruct \
  --served-model-name Qwen2.5-7B-Instruct
```

## 2) Configure environment

```bash
export VLLM_BASE_URL="http://localhost:8001/v1"
export VLLM_MODEL="Qwen2.5-7B-Instruct"
```

## 3) Optional OCR dependencies

The demo can do OCR if these are installed. If not, it falls back to embedded menu text.

```bash
pip install -r demo/requirements.txt
```

If you want real OCR, install Tesseract on your system as well.

## 4) Run the demo

```bash
python demo/menu_form_demo.py --image menu_test_image/menu.png --limit 5
```

Optional flags:

- `--target-language vi` to translate summaries
- `--output demo/output.json` to write results to a file
- `--skip-ocr` to skip OCR and use the embedded fallback text

## Output

The script prints JSON with extracted items and a `dish_info` object per item. Each `dish_info` comes from `agent_vllm` and includes:

- `dish`
- `spicy_level`
- `macros`
- `summary`
- `image_url`
- `source`
